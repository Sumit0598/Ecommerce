import android.app.Activity;

public class UploadProductActivity extends Activity {
}

package com.example.ecommerceapplication

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.*

class UploadProductActivity : AppCompatActivity() {

    private lateinit var productPreviewImg: ImageView
    private lateinit var edtProductName: EditText
    private lateinit var edtProductPrice: EditText
    private lateinit var edtProductDes: EditText
    private lateinit var btnSelectProduct: Button
    private lateinit var btnUploadProduct: Button
    private lateinit var progressBar: ProgressBar

    private var selectedImageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload_product)

        // Initialize views
        productPreviewImg = findViewById(R.id.img_product_preview)
        edtProductName = findViewById(R.id.edt_product_name)
        edtProductPrice = findViewById(R.id.edt_product_price)
        edtProductDes = findViewById(R.id.edt_product_des)
        btnSelectProduct = findViewById(R.id.btn_select_product)
        btnUploadProduct = findViewById(R.id.btn_upload_product)
        progressBar = findViewById(R.id.progress_bar)

        // Handle image selection
        btnSelectProduct.setOnClickListener {
            val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(galleryIntent, 101)
        }

        // Handle upload button click
        btnUploadProduct.setOnClickListener {
            lifecycleScope.launch {
                uploadProductDetails()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            selectedImageUri = data?.data
            if (selectedImageUri != null) {
                productPreviewImg.setImageURI(selectedImageUri)
            } else {
                Toast.makeText(this, "Failed to select image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    suspend private fun uploadProductDetails() {
        val productName = edtProductName.text.toString().trim()
        val productPrice = edtProductPrice.text.toString().trim()
        val productDes = edtProductDes.text.toString().trim()

        // Validate inputs
        if (productName.isEmpty() || productPrice.isEmpty() || productDes.isEmpty() || selectedImageUri == null) {
            Toast.makeText(this, "Please fill all fields and select an image", Toast.LENGTH_SHORT).show()
            return
        }

        progressBar.visibility = View.VISIBLE

        // Create a unique product ID
        val productId = UUID.randomUUID().toString()

        // Prepare product details
        var product = Product(
            productId = productId,
            productName = productName,
            productDes = productDes,
            productPrice = productPrice,
            productImageUri = selectedImageUri.toString() // Store the image URI as a string
        )
        try {
            val ref =
                FirebaseStorage.getInstance().reference.child("product_img/${product.productName}")
            ref.putFile(selectedImageUri!!).await()
            val url = ref.downloadUrl.await()
            product.productImageUri = url.toString()
        }catch (e:Exception){
            product.productImageUri=UrlUtils.getUrl
        }



        // Save product details in Firebase Realtime Database
        Firebase.database.getReference("products").child(productId).setValue(product)
            .addOnSuccessListener {
                progressBar.visibility = View.GONE
                Toast.makeText(this, "Product uploaded successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                progressBar.visibility = View.GONE
                Toast.makeText(this, "Failed to upload product details", Toast.LENGTH_SHORT).show()
            }
    }

    // Product data model class
    data class Product(
        val productId: String = "",
        val productName: String = "",
        val productDes: String = "",
        val productPrice: String = "",
        var productImageUri: String = "" // Store image URI as a string
    )
}

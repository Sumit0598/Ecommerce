package com.example.ecommerceapplication

import android.content.Context
import android.graphics.drawable.Drawable
import android.text.Layout
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.view.menu.MenuView.ItemView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import org.w3c.dom.Text
import java.security.PrivateKey

class ProductAdapter(
    private val listOfProducts:List<Product>,
    private val context: Context
):RecyclerView.Adapter<ProductAdapter.ProductViewHolder>(){
    class ProductViewHolder(
        itemView: View
    ):RecyclerView.ViewHolder(itemView){
        val productImg:ImageView=itemView.findViewById(R.id.product_img)
        val productName:TextView=itemView.findViewById(R.id.text_product_name)
        val productPrice:TextView=itemView.findViewById(R.id.text_product_price)
        val productDes:TextView=itemView.findViewById(R.id.text_product_des)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view=LayoutInflater.from(parent.context).inflate(R.layout.layout_product,parent,false)
        return ProductViewHolder(view)
    }

    override fun getItemCount(): Int {
       return listOfProducts.size
    }
    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val currentProduct=listOfProducts[position]
        holder.productName.text=currentProduct.productName
        holder.productPrice.text=currentProduct.productPrice
        holder.productDes.text=currentProduct.productDes
      Glide.with(context)
          .load(currentProduct.productImageUri)
          .listener(object : RequestListener<Drawable> {
              override fun onLoadFailed(
                  e: GlideException?,
                  model: Any?,
                  target: Target<Drawable>?,
                  isFirstResource: Boolean
              ): Boolean {
                  Log.d("Glide",e?.message.toString()+ currentProduct.toString())
                  return false
              }
              override fun onResourceReady(
                  resource: Drawable?,
                  model: Any?,
                  target: Target<Drawable>?,
                  dataSource: DataSource?,
                  isFirstResource: Boolean
              ): Boolean {
                  Log.d("Glide","Success")
                  return false
              }
          })
          .into(holder.productImg)

    }




}
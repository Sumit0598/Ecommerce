package com.example.ecommerceapplication

data class Product(
    val productName:String="",
    val productPrice:String="",
    val productDes:String="",
    val productImageUri:String=""
)

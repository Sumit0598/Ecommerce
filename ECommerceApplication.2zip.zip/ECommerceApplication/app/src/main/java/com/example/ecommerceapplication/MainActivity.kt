package com.example.ecommerceapplication

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {
    private lateinit var rv: RecyclerView
    private lateinit var productAdapter: ProductAdapter
    private val listOfProduct = mutableListOf<Product>() // List to hold product data
    private lateinit var fab: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)){
            v,insets->
            val systembars=insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systembars.left,systembars.top,systembars.right,systembars.bottom)
            insets
        }

        // Initialize RecyclerView and FloatingActionButton
        rv = findViewById(R.id.rv)
        fab = findViewById(R.id.fab)

        // Initialize ProductAdapter with the list of products


        // Fetch data from Firebase database
        FirebaseDatabase.getInstance().getReference("products")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    listOfProduct.clear() // Clear the list before adding new data
                    for (dataSnapshot in snapshot.children) {
                        val product =
                            dataSnapshot.getValue(Product::class.java) // Map data to Product class

                        listOfProduct.add(product!!) // Add product to the list
                    }
                    productAdapter=ProductAdapter(listOfProduct,this@MainActivity)
                rv.adapter=productAdapter
                rv.layoutManager=GridLayoutManager(this@MainActivity,2)// Notify adapter of data changes
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle the error (optional: log or show a toast)
                }
            })

        // Set FAB click listener to navigate to LoginActivity
        fab.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java)
            )
        }
    }
}
